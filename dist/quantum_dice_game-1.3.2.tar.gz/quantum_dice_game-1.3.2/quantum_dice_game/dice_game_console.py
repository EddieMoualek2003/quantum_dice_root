def dice_console_main():
    print("Dice Game - Console Mode.")