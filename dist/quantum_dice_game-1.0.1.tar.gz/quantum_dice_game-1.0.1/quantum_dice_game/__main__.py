from .game import run

if __name__ == "__main__":
    print("Starting Quantum Dice Game")
    run()
