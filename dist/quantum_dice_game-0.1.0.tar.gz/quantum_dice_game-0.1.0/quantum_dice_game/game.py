from . import dice_game_main

def run():
    print("Starting Quantum Dice Game...")
    dice_game_main.main()
