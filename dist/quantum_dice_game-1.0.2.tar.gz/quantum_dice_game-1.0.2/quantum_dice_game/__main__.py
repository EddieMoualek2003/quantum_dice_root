from .game import run

def main():
    """Entry point for the Quantum Dice Game."""
    print("Starting Quantum Dice Game")
    run()

if __name__ == "__main__":
    main()
